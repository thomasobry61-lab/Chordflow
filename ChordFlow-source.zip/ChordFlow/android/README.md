# Android wrapper — ChordFlow

Ce dossier réserve la place à un wrapper Android WebView. Pour produire un APK, ouvrir/créer le projet dans Android Studio avec Android SDK et Gradle, copier les fichiers web dans `app/src/main/assets/`, puis compiler un APK debug ou signer un APK release. Aucun APK n'est inclus à ce stade : l'environnement de création utilisé n'a pas d'Android SDK ni de Gradle installés.
