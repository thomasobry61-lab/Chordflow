# ChordFlow

Prototype d'application guitare au design clair et minimaliste. Fonctionnalités présentes :
- recherche YouTube (ouvre les résultats YouTube officiels, avec suggestions de requêtes locales)
- lecture d'une vidéo YouTube en collant son URL
- timeline d'accords de démonstration synchronisée avec le chronomètre de session
- transposition des accords et réglage de capodastre
- métronome avec clic audio et tempo 40–220 BPM
- interface responsive et PWA installable depuis un navigateur compatible

## Lancer en local
Servir ce dossier par HTTP (nécessaire pour le service worker), par exemple :

```bash
python -m http.server 8080
```
Puis ouvrir `http://localhost:8080`.

## Limites actuelles
La recherche ouvre YouTube plutôt que d'afficher son catalogue dans l'app : une recherche API en direct nécessite un accès conforme à une API de recherche et généralement une clé. La timeline contient des accords de démonstration et ne détecte pas automatiquement les accords de la vidéo. L'iframe YouTube est intégrée conformément aux possibilités du lecteur embarqué, mais sa lecture ne pilote pas encore le chronomètre des accords.

Le dossier Android est un squelette natif WebView pour servir de base à un APK. Il n'est pas compilé dans cet environnement faute d'Android SDK/Gradle installé. Voir `android/README.md`.
